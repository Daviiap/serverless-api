module.exports.handler = (event) => {
  return JSON.stringify({
    hello: 'world!'
  });
}