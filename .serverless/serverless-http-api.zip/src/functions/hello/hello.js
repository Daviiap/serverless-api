module.exports.handle = (event) => {
  return JSON.stringify({
    hello: 'world!',
    event
  });
}